# SketchFetch
## Real Time Web-based Pictionary game
## By Asmod, Dev, Sebastian

## Dependencies:
* Node.js
* Express
* Socket.io

*description*